# IPL-Prediction
Indian Premier League match prediction using machine learning
