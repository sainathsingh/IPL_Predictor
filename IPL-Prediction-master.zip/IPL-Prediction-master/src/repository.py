import pandas

ball_by_ball_df = pandas.read_csv('../data/Ball_by_Ball.csv')
match_df = pandas.read_csv('../data/Match.csv')
player_match_df = pandas.read_csv('../data/Player_Match.csv')
player_df = pandas.read_csv('../data/Player.csv')
season_df = pandas.read_csv('../data/Season.csv')
team_df = pandas.read_csv('../data/Team.csv')
